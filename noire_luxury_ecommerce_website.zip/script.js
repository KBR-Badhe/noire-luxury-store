const products=[
{name:"Obsidian Vase",category:"decor",price:4200,bg:"#4a4337",rotate:"-8deg"},
{name:"Noir Leather Tote",category:"fashion",price:8900,bg:"#242321",rotate:"5deg"},
{name:"Aurum Candle",category:"gifts",price:2600,bg:"#8e7650",rotate:"-3deg"},
{name:"Sculptural Tray",category:"decor",price:5100,bg:"#7b6a50",rotate:"7deg"},
{name:"Silk Evening Scarf",category:"fashion",price:6400,bg:"#665449",rotate:"-5deg"},
{name:"Signature Gift Box",category:"gifts",price:3500,bg:"#40382c",rotate:"4deg"},
{name:"Stone Incense Set",category:"decor",price:2900,bg:"#777064",rotate:"-6deg"},
{name:"Atelier Wallet",category:"fashion",price:7200,bg:"#302b25",rotate:"5deg"}
];

let cart=JSON.parse(localStorage.getItem("noire-cart")||"[]");

const money=n=>"₹"+n.toLocaleString("en-IN");
const grid=document.getElementById("productGrid");

function renderProducts(category="all"){
  grid.innerHTML="";
  products.filter(p=>category==="all"||p.category===category).forEach((p,i)=>{
    const el=document.createElement("article");
    el.className="product";
    el.innerHTML=`<div class="product-img" style="--product-bg:${p.bg};--rotate:${p.rotate}">
      ${i<2?'<span class="product-tag">SIGNATURE</span>':''}</div>
      <div class="product-info"><h3>${p.name}</h3><p>${p.category.toUpperCase()}</p>
      <span class="price">${money(p.price)}</span><button class="add">+ ADD</button></div>`;
    el.querySelector(".add").onclick=()=>addToCart(p);
    grid.appendChild(el);
  });
}
function addToCart(p){
  const item=cart.find(x=>x.name===p.name);
  item?item.qty++:cart.push({...p,qty:1});
  saveCart(); renderCart(); openCart();
}
function saveCart(){localStorage.setItem("noire-cart",JSON.stringify(cart));}
function renderCart(){
  const box=document.getElementById("cartItems");
  document.getElementById("cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);
  box.innerHTML=cart.length?cart.map((p,i)=>`<div class="cart-item">
    <div class="cart-thumb" style="--product-bg:${p.bg}"></div>
    <div><h4>${p.name}</h4><small>${money(p.price)} × ${p.qty}</small></div>
    <button class="remove" onclick="removeItem(${i})">×</button>
  </div>`).join(""):"<p style='color:#777;padding:30px 0'>Your bag is currently empty.</p>";
  document.getElementById("cartTotal").textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0));
}
function removeItem(i){cart.splice(i,1);saveCart();renderCart()}
function openCart(){document.getElementById("cartPanel").classList.add("open");document.getElementById("cartBackdrop").classList.add("open")}
function closeCart(){document.getElementById("cartPanel").classList.remove("open");document.getElementById("cartBackdrop").classList.remove("open")}
document.getElementById("cartBtn").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
document.getElementById("cartBackdrop").onclick=closeCart;

document.querySelectorAll(".filter").forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));
 btn.classList.add("active"); renderProducts(btn.dataset.category);
});

const overlay=document.getElementById("searchOverlay");
document.getElementById("searchBtn").onclick=()=>{overlay.classList.add("open");document.getElementById("searchInput").focus();};
document.getElementById("closeSearch").onclick=()=>overlay.classList.remove("open");
document.getElementById("searchInput").oninput=e=>{
 const q=e.target.value.toLowerCase();
 document.getElementById("searchResults").innerHTML=products.filter(p=>p.name.toLowerCase().includes(q)||p.category.includes(q))
 .map(p=>`<div class="search-result">${p.name}<span style="float:right;color:#b99a62">${money(p.price)}</span></div>`).join("") || "<p style='color:#777;margin-top:20px'>No pieces found.</p>";
};

document.getElementById("newsletterForm").onsubmit=e=>{
 e.preventDefault();document.getElementById("formMessage").textContent="Welcome to the NOIRÉ private list.";
 e.target.reset();
};
document.getElementById("checkoutBtn").onclick=()=>{
 if(!cart.length)return alert("Your bag is empty.");
 alert("Demo checkout: connect this button to your payment/order system before accepting real orders.");
};
renderProducts();renderCart();
